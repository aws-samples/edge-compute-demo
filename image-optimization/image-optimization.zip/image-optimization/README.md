## Image Compression 

We can build a solution for dynamic image compression on Amazon Cloud through various services such as Amazon CloudFront, Amazon CloudFront Edge Function, Amazon Lambda, and Amazon S3. Please refer to this link(https://github.com/aws-samples/image-optimization) for specific details of the solution. The current solution achieves dynamic compression and clipping through the following methods:
* Users send HTTP requests containing images with specific transformations (such as encoding and size). These conversions are encoded into URLs, more precisely query parameters. The example URL is as follows: https://examples.com/images/cats/mycat.jpg?format=webp&width=200 .
* This request is processed by a nearby CloudFront edge site and will execute the CloudFront Function in the viewer request event to rewrite the request URL. CloudFront Functions is a feature of CloudFront that allows you to write lightweight functions using JavaScript to achieve large-scale, latency sensitive CDN customization. In the current architecture, we will rewrite the URL to validate the conversion of requests and normalize the URL by sorting the conversions and converting them to lowercase, thereby improving cache hit rates. When requesting automatic conversion, this function also determines the optimal conversion to be applied. For example, if a user requests the optimal image format (JPEG, WebP, or AVIF) using the command format=auto, CloudFront Function will select the best format based on the Accept header in the request.
* If the image is not in the CloudFront cache, the request will be forwarded to the S3 bucket, which is dedicated to storing the converted image. If the requested image has been converted and stored in S3, it only needs to be provided and cached in CloudFront.

## Customer requirements

* The current prerequisite for implementing compression is that the client needs to undergo some degree of modification and support adding request parameters to the request URL. For most scenarios, users only need to compress the image without cropping, and do not want to make changes to the client code
* When updating or deleting the original image, it is necessary to also delete the converted image in S3 and clear the current CloudFront cache to ensure that users can request the latest version of compressed images
* For the same CloudFront distribution, both image and non image requests can be processed simultaneously


## What optimizations have we made

* Without modifying the access URL, determine which compression formats the client can support based on the accept header carried by the client. If both avif and webp are carried, prioritize compressing avif.  
* Clarify the processing logic for image and non image requests. Create a new S3 source site for storing behavior and original images, triggering image processing logic only for files with JPEG, JPG, PNG, and GIF suffixes, and directly responding to source files with other suffixes
* After updating the source bucket file, delete the corresponding compressed image and call the Cloudfront API to clear the specified cache