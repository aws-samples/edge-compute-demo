function handler(event) {
    var request = event.request;
    var originalImagePath = request.uri;
    
    // 根据 Accept header 确定最佳格式
var format = 'jpeg';
    if (originalImagePath.includes('.gif')) {
        format = 'webp'; // If the URI contains .gif, set format to webp
    } else if (originalImagePath.includes('.webp')) {
        format = 'webp'; // If the URI contains .webp, set format to webp
    } else if (originalImagePath.includes('.jpg')) {
        format = 'webp'; // If the URI contains .jpg, set format to webp
    }else if (originalImagePath.includes('.png')) {
        format = 'webp'; // If the URI contains .png, set format to webp
    }
    else if (originalImagePath.includes('.svg')) {
        format = 'webp'; // If the URI contains .webp, set format to webp
    }else if (request.headers['accept']) {
        if (request.headers['accept'].value.includes("avif")) {
            format = 'avif';
        } else if (request.headers['accept'].value.includes("webp")) {
            format = 'webp';
        }
    }

    // 只添加format参数，使用原图尺寸
    request.uri = originalImagePath + '/format=' + format;
    
    // 清空查询参数
    request['querystring'] = {};
    return request;
}