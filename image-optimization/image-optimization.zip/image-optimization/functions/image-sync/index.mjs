// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

import { S3Client, HeadObjectCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";
import { CloudFrontClient, CreateInvalidationCommand } from "@aws-sdk/client-cloudfront";

const s3Client = new S3Client();
const cloudfrontClient = new CloudFrontClient();

/**
 * Check if an S3 object exists
 * @param {string} bucket - S3 bucket name
 * @param {string} key - S3 object key
 * @returns {Promise<boolean>} - True if object exists, false otherwise
 */
async function checkObjectExists(bucket, key) {
  try {
    await s3Client.send(new HeadObjectCommand({ Bucket: bucket, Key: key }));
    return true;
  } catch (error) {
    if (error.name === 'NotFound' || error.$metadata?.httpStatusCode === 404) {
      return false;
    }
    console.error(`Error checking object existence: ${error.message}`);
    throw error;
  }
}

/**
 * Invalidate CloudFront cache for specified paths
 * @param {string} distributionId - CloudFront distribution ID
 * @param {string[]} paths - Paths to invalidate
 * @returns {Promise<string>} - Invalidation ID
 */
async function invalidateCloudFrontCache(distributionId, paths) {
  try {
    const response = await cloudfrontClient.send(new CreateInvalidationCommand({
      DistributionId: distributionId,
      InvalidationBatch: {
        Paths: {
          Quantity: paths.length,
          Items: paths
        },
        CallerReference: `image-sync-${Date.now()}`
      }
    }));
    
    console.log(`Invalidation created: ${response.Invalidation.Id}`);
    return response.Invalidation.Id;
  } catch (error) {
    console.error(`Error creating invalidation: ${error.message}`);
    throw error;
  }
}

export const handler = async (event) => {
  // Get environment variables
  const targetBucket = process.env.TRANSFORMED_IMAGE_BUCKET;
  const distributionId = process.env.CLOUDFRONT_DISTRIBUTION_ID;
  
  if (!targetBucket || !distributionId) {
    console.error('Missing required environment variables');
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Missing required environment variables' })
    };
  }

  // Process results
  const results = {
    checked: [],
    deleted: [],
    skipped: [],
    invalidated: []
  };

  try {
    // Process each record in the S3 event
    for (const record of event.Records) {
      // Get the source file key and decode it
      const sourceKey = decodeURIComponent(record.s3.object.key.replace(/\+/g, ' '));
      console.log(`Processing file: ${sourceKey}`);

      // Check if the file is an image (we only care about images)
      const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif'];
      const hasImageExtension = imageExtensions.some(ext => 
        sourceKey.toLowerCase().endsWith(ext)
      );

      if (!hasImageExtension) {
        console.log(`Skipping non-image file: ${sourceKey}`);
        continue;
      }

      // Define the variants to check and delete
      const variants = [
        `${sourceKey}/format=avif`,
        `${sourceKey}/format=webp`,
        `${sourceKey}/format=jpeg`
      ];

      const cloudfrontPaths = [];

      // Check and delete each variant
      for (const variantKey of variants) {
        results.checked.push(variantKey);
        console.log(`Checking in target bucket: ${variantKey}`);

        try {
          // Check if the variant exists
          const exists = await checkObjectExists(targetBucket, variantKey);
          
          if (exists) {
            // Delete the variant
            await s3Client.send(new DeleteObjectCommand({
              Bucket: targetBucket,
              Key: variantKey
            }));
            
            results.deleted.push(variantKey);
            cloudfrontPaths.push(`/${variantKey}`);
            console.log(`Successfully deleted: ${variantKey}`);
          } else {
            results.skipped.push(variantKey);
            console.log(`File does not exist in target bucket, skipping: ${variantKey}`);
          }
        } catch (error) {
          console.error(`Error processing ${variantKey}: ${error.message}`);
        }
      }

      // Invalidate CloudFront cache if needed
      if (cloudfrontPaths.length > 0) {
        try {
          await invalidateCloudFrontCache(distributionId, cloudfrontPaths);
          results.invalidated = cloudfrontPaths;
        } catch (error) {
          console.error(`Error invalidating CloudFront cache: ${error.message}`);
        }
      }
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Processing completed',
        results
      })
    };
  } catch (error) {
    const errorMessage = `Error in lambda execution: ${error.message}`;
    console.error(errorMessage);
    
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: errorMessage,
        results
      })
    };
  }
};